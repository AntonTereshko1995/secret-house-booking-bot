from enum import Enum


class Bedroom(Enum):
    WHITE = 0
    GREEN = 1
