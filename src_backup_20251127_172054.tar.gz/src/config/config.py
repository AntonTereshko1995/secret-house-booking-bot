from dotenv import load_dotenv
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from src.services.secret_manager_service import SecretManagerService

secret_manager_service = SecretManagerService()

TELEGRAM_CONTACT = "https://t.me/the_secret_house"
PERIOD_IN_MONTHS = 6
MAX_PERIOD_FOR_GIFT_IN_MONTHS = 3
PREPAYMENT = 80
CLEANING_HOURS = 2
MIN_BOOKING_HOURS = 1

if "secrets-production" in os.environ:
    secrets = secret_manager_service.get_secret_by_dict("the-secret-house-secret")
    DEBUG = False
    TELEGRAM_TOKEN = secrets.get("TELEGRAM_TOKEN")
    LOGTAIL_TOKEN = secrets.get("LOGTAIL_TOKEN")
    LOGTAIL_SOURCE = secrets.get("LOGTAIL_SOURCE")
    DATABASE_URL = secrets.get("DATABASE_URL")
    ADMIN_CHAT_ID = int(secrets.get("ADMIN_CHAT_ID"))
    INFORM_CHAT_ID = int(secrets.get("INFORM_CHAT_ID"))
    GPT_KEY = secrets.get("GPT_KEY")
    GPT_PROMPT = secrets.get("GPT_PROMPT")
    CALENDAR_ID = secrets.get("CALENDAR_ID")
    BANK_CARD_NUMBER = secrets.get("BANK_CARD_NUMBER")
    BANK_PHONE_NUMBER = secrets.get("BANK_PHONE_NUMBER")
    ADMINISTRATION_CONTACT = secrets.get("ADMINISTRATION_CONTACT")
    GOOGLE_CREDENTIALS = secret_manager_service.get_secret("GOOGLE_CREDENTIALS")
    REDIS_URL = secret_manager_service.get_secret("REDIS_URL")
    REDIS_PORT = secret_manager_service.get_secret("REDIS_PORT")
    REDIS_SSL = secret_manager_service.get_secret("REDIS_SSL")
    SETTINGS_PATH = secret_manager_service.get_secret("SETTINGS_PATH")
else:
    if os.environ.get("AMVERA") != 1:
        file = (
            "src/config/.env.debug"
            if os.getenv("ENV") == "debug"
            else "src/config/.env.production"
        )
        load_dotenv(file)

    DEBUG = os.getenv("DEBUG").strip().lower() in ("true", "1", "yes", "on")
    GOOGLE_CREDENTIALS = os.getenv("GOOGLE_CREDENTIALS")
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
    LOGTAIL_TOKEN = os.getenv("LOGTAIL_TOKEN")
    LOGTAIL_SOURCE = os.getenv("LOGTAIL_SOURCE")
    DATABASE_URL = os.getenv("DATABASE_URL")
    ADMIN_CHAT_ID = int(os.getenv("ADMIN_CHAT_ID"))
    INFORM_CHAT_ID = int(os.getenv("INFORM_CHAT_ID"))
    GPT_KEY = os.getenv("GPT_KEY")
    GPT_PROMPT = os.getenv("GPT_PROMPT")
    CALENDAR_ID = os.getenv("CALENDAR_ID")
    BANK_CARD_NUMBER = os.getenv("BANK_CARD_NUMBER")
    BANK_PHONE_NUMBER = os.getenv("BANK_PHONE_NUMBER")
    ADMINISTRATION_CONTACT = os.getenv("ADMINISTRATION_CONTACT")
    REDIS_URL = os.getenv("REDIS_URL")
    REDIS_PORT = os.getenv("REDIS_PORT")
    REDIS_SSL = os.getenv("REDIS_SSL")
    SETTINGS_PATH = os.getenv("SETTINGS_PATH")
